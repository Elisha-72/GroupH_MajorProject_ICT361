package com.example.farmerweathernotes.network;

import com.example.farmerweathernotes.model.LocationProfile;
import com.example.farmerweathernotes.model.DailyNote;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.POST;
import retrofit2.http.Body;

public interface ApiService {

    // Locations
    @GET("api/locations")
    Call<List<LocationProfile>> getAllLocations();

    @POST("api/locations")
    Call<LocationProfile> createLocation(@Body LocationProfile location);

    // Daily Notes
    @GET("api/notes")
    Call<List<DailyNote>> getAllNotes();

    @GET("api/notes/byLocation/{locationId}")
    Call<List<DailyNote>> getNotesByLocation(@Path("locationId") Long locationId);

    @GET("api/notes/byLocationAndDate/{locationId}/{date}")
    Call<List<DailyNote>> getNotesByLocationAndDate(@Path("locationId") Long locationId,
                                                    @Path("date") String date);

    @POST("api/notes")
    Call<DailyNote> createNote(@Body DailyNote note);
}
