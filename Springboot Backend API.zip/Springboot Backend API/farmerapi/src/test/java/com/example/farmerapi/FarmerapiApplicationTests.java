package com.example.farmerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
