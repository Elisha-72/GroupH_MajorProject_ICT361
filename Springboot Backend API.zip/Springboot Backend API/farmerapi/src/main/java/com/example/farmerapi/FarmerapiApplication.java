package com.example.farmerapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmerapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmerapiApplication.class, args);
	}

}
